#!/bin/bash
set -e

# Run any additional setup scripts included in the shared/devcontainer directory. This is to allow for per developer or
# per-environment customizations. These scripts are not checked into source control.
if [ -x "/persist/shared/devcontainer/install" ]; then
  /persist/shared/devcontainer/install
fi

# Create a symlink to the shared .scratch directory for temporary files if it exists.
if [ -x "/persist/shared/.scratch" ]; then
  if [ ! -e .scratch ] && [ ! -L .scratch ]; then
    ln -s /persist/shared/.scratch
  fi
fi

# Everything that sets up the project itself lives in the same task a native checkout runs:
# allocate this checkout's ports and decode its client certificates. The container keeps no
# project setup logic of its own. `mise run dev` then starts PostgreSQL 18 and the supervisor.
mise run dev:init
