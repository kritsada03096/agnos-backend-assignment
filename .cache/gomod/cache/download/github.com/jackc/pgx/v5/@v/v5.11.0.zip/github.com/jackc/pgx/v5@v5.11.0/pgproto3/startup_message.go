package pgproto3

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	"github.com/jackc/pgx/v5/internal/pgio"
)

const (
	ProtocolVersion30     = 196608            // 3.0
	ProtocolVersion32     = 196610            // 3.2
	ProtocolVersionLatest = ProtocolVersion32 // Latest is 3.2
	ProtocolVersionNumber = ProtocolVersion30 // Default is still 3.0
)

type StartupMessage struct {
	ProtocolVersion uint32
	Parameters      map[string]string
}

// Frontend identifies this message as sendable by a PostgreSQL frontend.
func (*StartupMessage) Frontend() {}

// Decode decodes src into dst. src must contain the complete message with the exception of the initial 1 byte message
// type identifier and 4 byte message length.
func (dst *StartupMessage) Decode(src []byte) error {
	if len(src) < 4 {
		return errors.New("startup message too short")
	}

	dst.ProtocolVersion = binary.BigEndian.Uint32(src)
	rp := 4

	if dst.ProtocolVersion != ProtocolVersion30 && dst.ProtocolVersion != ProtocolVersion32 {
		return fmt.Errorf("Bad startup message version number. Expected %d or %d, got %d", ProtocolVersion30, ProtocolVersion32, dst.ProtocolVersion)
	}

	dst.Parameters = make(map[string]string)
	for {
		idx := bytes.IndexByte(src[rp:], 0)
		if idx < 0 {
			return &invalidMessageFormatErr{messageType: "StartupMessage"}
		}
		key := string(src[rp : rp+idx])
		rp += idx + 1

		idx = bytes.IndexByte(src[rp:], 0)
		if idx < 0 {
			return &invalidMessageFormatErr{messageType: "StartupMessage"}
		}
		value := string(src[rp : rp+idx])
		rp += idx + 1

		dst.Parameters[key] = value

		if len(src[rp:]) == 1 {
			if src[rp] != 0 {
				return fmt.Errorf("Bad startup message last byte. Expected 0, got %d", src[rp])
			}
			break
		}
	}

	return nil
}

// Encode encodes src into dst. dst will include the 1 byte message type identifier and the 4 byte message length.
func (src *StartupMessage) Encode(dst []byte) ([]byte, error) {
	sp := len(dst)
	dst = pgio.AppendInt32(dst, -1)

	dst = pgio.AppendUint32(dst, src.ProtocolVersion)
	for k, v := range src.Parameters {
		// The startup message body is a run of NUL-delimited strings whose
		// length is data-driven: the server keeps reading name/value pairs
		// until the empty name that terminates the list. Other messages have a
		// field count fixed by the message type, so a stray NUL there leaves
		// trailing bytes and the server rejects the message; here it simply
		// yields more parameters. A libpq caller cannot reach this state
		// because its parameters are NUL-terminated C strings, but a Go string
		// can carry a NUL, so an application_name of "x\x00user\x00admin"
		// would silently change the role the connection logs in as. Refuse to
		// encode instead.
		if strings.IndexByte(k, 0) >= 0 {
			return nil, errors.New("startup message parameter name contains NUL byte")
		}
		if strings.IndexByte(v, 0) >= 0 {
			// Name the parameter but not the value: values can hold secrets.
			return nil, fmt.Errorf("startup message parameter %q contains NUL byte in value", k)
		}

		dst = append(dst, k...)
		dst = append(dst, 0)
		dst = append(dst, v...)
		dst = append(dst, 0)
	}
	dst = append(dst, 0)

	return finishMessage(dst, sp)
}

// MarshalJSON implements encoding/json.Marshaler.
func (src StartupMessage) MarshalJSON() ([]byte, error) {
	return json.Marshal(struct {
		Type            string
		ProtocolVersion uint32
		Parameters      map[string]string
	}{
		Type:            "StartupMessage",
		ProtocolVersion: src.ProtocolVersion,
		Parameters:      src.Parameters,
	})
}
