# 5.11.0 (September 7, 2026)

This release adds direct PostgreSQL type scanning through `database/sql` on Go 1.27, improves compatibility with
libpq connection strings and PostgreSQL date/time values, and includes further decoder hardening. See Changes for
connection-string and date/time behavior changes that may affect existing applications.

## Features

* stdlib: support Go 1.27's `driver.RowsColumnScanner`, allowing PostgreSQL types such as arrays and ranges to be
  scanned directly into Go values without `pgtype.Map.SQLScanner`. Existing `database/sql` scalar conversions and
  `sql.Scanner` behavior are preserved. The minimum supported Go version remains 1.25.
* Add `Rows.TypeMap` to expose the type map used to decode rows, including rows created by `RowsFromResultReader`
  that have no underlying `Conn`. Custom implementations of `Rows`, including mocks, must add this method.
* pgconn: add `Config.MaxProtocolMessageBodyLen` to configure the maximum incoming protocol message body size
  (carter-ya)
* pgconn: add `ErrReadOnlyConnection`, `ErrReadWriteConnection`, `ErrPrimaryConnection`, and `ErrStandbyConnection`
  sentinel errors for `target_session_attrs` validation, allowing callers to use `errors.Is` (Adrian-Stefan Mares)
* pgxpool: accept `pool_ping_timeout` in connection strings to configure `Config.PingTimeout`. The default is zero;
  zero and negative durations mean no timeout (1991santhu)

## Changes

* Name-based row-to-struct mapping now matches explicit `db` tags case-insensitively, with exact matches taking
  precedence so tags can still distinguish quoted column names that differ only by case (AlisinaDevelo)
* pgconn: resolve the OS user account only when no user is supplied by the connection string, environment, or service
  file, avoiding unnecessary account lookups and crashes in some restricted container environments. Home-directory
  defaults for password, service, and TLS files remain available independently of the account lookup. On Unix these
  now use `$HOME` rather than the OS account's home directory (Mohamed MAACHE)

* pgtype: `date`, `timestamp` and `timestamptz` text values are now parsed and written by a hand-written parser and
  encoder for PostgreSQL's ISO date/time format instead of `time.Parse` and `time.Format`. Go's layout language cannot
  express a variable-width year or the BC era, which is the root of the bugs below. The text scan path is roughly 2.5x
  faster for `timestamp` and `timestamptz`. Bug fixes:
  * `timestamp` and `timestamptz` no longer silently move February 29 of a BC leap year to March 1 when encoding.
    `time.Date(-4712, 2, 29, ...)` was written as `4713-03-01 BC` and is now written as `4713-02-29 BC`. This
    affected ordinary four-digit BC years, not only extended-range ones. `date` was never affected.
  * `timestamp` and `timestamptz` can now scan BC leap days. `4713-02-29 BC` previously failed with
    `day out of range`. `date` could already scan them.
  * Years past 9999 can now be scanned. `10000-01-02 03:04:05` previously failed to parse, so `timestamp` and
    `timestamptz` values at the high end of PostgreSQL's range were unreadable over the simple protocol and in any
    other text-format result.
  * `time.Time` arguments in the simple protocol now encode BC dates correctly, using the same timestamp encoder.
  * Fractional seconds beyond microsecond precision are rounded the way the server rounds them (round half to even,
    carrying into the rest of the value) instead of being kept at full precision. PostgreSQL never sends more than six
    fractional digits, so this only affects values from other sources.

  Behavior changes:
  * `date` now rejects impossible dates instead of normalizing them. `2024-02-30` returned `2024-03-01` and
    `2024-13-01` returned `2025-01-01`; both are now errors. `timestamp` and `timestamptz` already rejected them.
  * All three types now reject values outside PostgreSQL's range for that type, in the binary format as well as the
    text format. PostgreSQL never sends out-of-range dates, so this only affects corrupt or hand-built input; the range
    is checked in both formats so that whether a value is accepted does not depend on `QueryExecMode`.
    `timestamptz` also rejects time zone displacements outside PostgreSQL's signed 32-bit seconds range, while accepting
    the wider offsets emitted for POSIX time zones, such as `+16`.
  * `timestamptz` values scanned from the text format are now returned in `time.Local`, or in `ScanLocation` when it is
    set, matching what the binary format has always returned. Previously the text path kept whatever location
    `time.Parse` derived from the offset the server sent, so the same value scanned in the two formats could report a
    different `Location()` and `Zone()`. The instant is unchanged, but everything that renders the location changes
    with it: `Timestamptz.MarshalJSON` now writes the client's offset rather than the server's, so a value the server
    sent as `+05:30` marshals as `2024-01-01T13:34:05-08:00` on a UTC-8 client instead of `2024-01-02T03:04:05+05:30`,
    and `DecodeDatabaseSQLValue` hands `database/sql` a `time.Time` in that same location. Set the codec's
    `ScanLocation` to `time.UTC` to pin the location regardless of the client's zone.
  * Error messages from these paths have changed.

* pgconn: connection URIs (`postgres://...`) are now parsed by a new parser designed to exactly match libpq's URI
  parser behavior instead of `net/url`,
  making pgx accept and reject exactly the same URIs as libpq (verified by differential fuzzing against libpq itself).
  Most connection strings are unaffected. Edge-case behavior changes, all matching libpq:
  * `+` in query values is literal, no longer decoded as a space.
  * Malformed percent-encoding is a parse error instead of the parameter being silently dropped. `%00` is rejected.
  * Leading/trailing spaces in URI components are trimmed; interior spaces are a parse error (encode them as `%20`).
  * `#` is ordinary data, not a fragment delimiter.
  * The userinfo terminator is the first `@` before any `/` (previously the last `@`).
  * When a query parameter is repeated, the last occurrence wins (previously the first).
  * `ssl=true` is accepted as an alias for `sslmode=require` in URIs (JDBC compatibility). A repeated `ssl` key
    follows the same last-occurrence-wins rule as other repeated parameters, even across the rewrite to `sslmode`. If
    the final `ssl` value is not `true`, an independent explicit `sslmode` remains in effect.
  * Multiple hosts with mixed port specs are positionally aligned: `postgres://h1,h2:5433/db` now means h1:5432 and
    h2:5433 (previously both hosts got port 5433). A port list that is neither a single port nor exactly one port per
    host is an error (`could not match N port numbers to M hosts`), also for keyword/value connection strings.
  * An IPv6 address in a URI must be enclosed in brackets. A bare `postgres://::1/db` was previously accepted as host
    `::1`; it is now read as an empty host followed by port `:1` and fails with an invalid port error. Write it as
    `postgres://[::1]/db`.
  * Empty host list elements (e.g. `h1,,h2`) get the default host instead of being dropped. Likewise, an empty host in
    a keyword/value string (`host=`) now means the default host -- typically the Unix socket directory -- where it
    previously meant a TCP connection to an empty hostname.
  * An empty port (`?port=` in a URI or `port=` in a keyword/value string) now means the default port 5432 for the
    affected hosts; previously it was an invalid port error. Like any connection-string port, a present-but-empty port
    takes precedence over `PGPORT`.
  * ASCII control characters (tab, newline, ...) in a URI are ordinary data bytes, as they are to libpq; `net/url`
    rejected any URI containing one. The exception is a literal NUL byte, which is still rejected, as `net/url` did.
    (libpq never sees one -- C strings end at the first NUL -- but in Go a raw NUL could otherwise pass through into
    the NUL-delimited startup message and inject extra parameters.)

  Unlike libpq, unrecognized URI query parameters are still accepted (they become runtime parameters or pgx-specific
  options). Parse error messages avoid quoting the unredacted connection string and redact recognizable password
  fields on a best-effort basis. Invalid connection strings can be structurally ambiguous, so password redaction
  cannot be guaranteed for every malformed input.

* pgconn: keyword/value connection strings (`host=... user=...`) now match libpq's parser exactly, the same treatment
  the URI parser received above and verified the same way, by differential fuzzing against libpq itself. Most
  connection strings are unaffected. Behavior changes, all matching libpq:
  * A backslash escapes whatever character follows it and is dropped, where previously only `\\` and `\'` were
    unescaped and every other backslash was kept. A value containing a backslash must now escape it, as libpq
    requires: `sslcert=C:\path\to\cert` reads as `C:pathtocert` and has to be written `sslcert=C:\\path\\to\\cert`.
    This mainly affects Windows certificate and key paths, which previously came through intact without doubling.
  * A trailing backslash in an unquoted value escapes the end of the string, so it is dropped and the value ends
    there; it was previously rejected with `invalid backslash`. Inside a quoted value the escaped terminator leaves
    the string unterminated, which is still an error.
  * Whitespace inside a keyword is an error (`missing "=" after "us" in connection info string`) instead of becoming
    part of the key. Whitespace around the `=` is unaffected. This most often shows up with an unquoted value
    containing a space: `application_name=my app host=x` previously set neither parameter and sent `app host` to the
    server as a runtime parameter, and now fails to parse.

  As with URIs, unrecognized keywords are still accepted where libpq rejects them, and an empty `user=` is still
  dropped so that `PGUSER` and the OS user still apply.

## Fixes

* Keep the connection open after a recoverable PostgreSQL error from `Begin` or `BeginTx`
  (Victor Alejandro Sanz Ararat)
* Call `TraceQueryEnd` when `Exec` fails while deallocating invalidated cached statements (Chris Bandy)
* Deallocate a failed prepare using the statement name actually sent to the server, and skip cleanup if Parse never
  completed, avoiding leaked prepared statements and unnecessary cleanup errors (Eliran Ben-Zikri)
* Fix `LoadTypes` overwriting scalar codecs such as `box` and `point` with an incorrect `ArrayCodec` (Arsen Ozhetov)
* pgconn: retrieve field descriptions when cached descriptions are empty, such as for cursor `FETCH` statements,
  including batch and pipeline execution (water)
* pgconn: keep batch statement descriptions and result formats aligned when commands return no rows or when
  `Batch.ExecStatement` is mixed with other batch commands; preserve field descriptions for empty results
* pgconn: handle empty and comment-only queries in pipeline mode, discard stale statement data after bind errors,
  and return a nil result from `Pipeline.GetResults` on error
* pgconn: skip reading the password file when a password is already set (Jared Fowkes)
* pgxpool: treat non-positive `MaxConnLifetime` values as unlimited instead of immediately expiring connections
  (Aurelien Pillevesse)
* pgtype: support non-comma text array delimiters through `ArrayCodec.Delimiter`, including the semicolon delimiter
  used by `box[]`. `LoadType` and `LoadTypes` now load the delimiter from PostgreSQL (Sueun Cho)
* pgtype: quote text array elements containing internal whitespace (Louisa Huang)
* pgtype: quote and escape text range bounds containing delimiters, quotes, or backslashes, and distinguish empty
  string bounds from unbounded ranges (Sueun Cho)
* pgtype: preserve decimal precision in `Numeric.ScanScientific` and accept scientific notation in
  `Numeric.UnmarshalJSON`; reject out-of-range scientific exponents and preserve the original input in parse errors
  (Sueun Cho)
* pgtype: encode and decode numeric infinity in JSON as `"Infinity"` and `"-Infinity"` instead of encoding it as zero
  (Vladimir Saraikin)
* pgtype: treat a valid `Numeric` with a nil `Int` as zero in `Int64Value`, and return errors when converting NaN or
  infinity to an integer instead of panicking (Vladimir Saraikin)
* pgtype: fix an infinite loop when decoding binary numeric zero with a nonzero digit count (Vladimir Saraikin)
* pgtype: fix binary numeric digit-count overflow and trailing-byte handling. Binary encoding now rejects values
  whose digit count, weight, or scale cannot fit the wire format, while accepting the full unsigned digit-count range.
* pgtype: fix scanning through multiple pointer levels, including SQL NULL and XML values, and return an error
  instead of panicking when a pointer-to-pointer scan destination is nil (Rangel Reale)
* pgtype: use bounds-checked binary reads throughout the codecs and reject malformed lengths, counts, and trailing
  data. This includes fixes for panics on malformed records and truncated multiranges (Vladimir Saraikin), and
  validation of `bit` / `varbit` bit lengths against the actual data (g3m0sis).
* pgtype: return errors instead of panicking on malformed interval text (greymoth-jp), unterminated composite text
  fields, and text arrays whose dimensions and element counts disagree
* pgtype: cap the initial allocation estimate when parsing hstore text to avoid excessive allocation from unvalidated
  separator counts; valid hstores may still contain any number of pairs (AshSgDe29071999)
* pgtype: correct reversed bounds in integer scan error messages
* pgconn: a backslash as the last byte of a quoted value in a keyword/value connection string no longer panics with
  `slice bounds out of range`. `host='a\` -- and the shorter `='\`, reachable through `pgx.ParseConfig` and
  `pgxpool.ParseConfig` -- now return `unterminated quoted string in connection info string`, libpq's own message for
  the same input. The unquoted branch has been guarded since be69c1c1; the quoted branch carried the same unguarded
  increment since the parser was ported from pgx v3. Found by fuzzing (Maxim Korotkov)
* pgconn: error messages that embed the connection string now also redact `password` and `sslpassword` values supplied
  as URI query parameters; previously only the userinfo password was redacted. Redaction matches keys the way the
  parser does -- percent-encoded spellings such as `pass%77ord=` are recognized -- and masks the entire raw value, so
  a password containing a space cannot leak its tail into the error message. Credentials stranded outside the
  userinfo by a malformed URI are masked whole, and invalid-port errors no longer embed the offending text (which in
  a malformed URI can be a mislaid password). Redaction of invalid connection strings is necessarily best effort:
  their structure may be ambiguous, so some malformed inputs can still expose password text in an error.
* pgconn: `ParseConfigOptions.ConnStringAllowedKeys` no longer exempts an explicitly supplied empty port (`?port=` in
  a URI or `port=` in a keyword/value string) from the allow-list. Only the implied all-empty port list of a
  multi-host URI without ports (`postgres://h1,h2/db`) is exempt. An explicit empty port shadows `PGPORT` even though
  it is empty, so it must be allowed like any other user-supplied key. The URI-only `ssl=true` alias is accepted when
  either `ssl` or `sslmode` is allowed, and every `ssl`/`sslmode` spelling written in the URI is validated --
  including occurrences superseded by later repeated parameters.
* pgconn: drain socket before close in `asyncClose` so context cancellation produces a TCP FIN instead of RST, avoiding "connection reset by peer" on the server / proxy (Sean Chittenden at CrowdStrike, Inc.)
* pgproto3: `StartupMessage.Encode` rejects a NUL byte in any parameter name or value instead of writing it. The
  startup message body is a run of NUL-delimited strings whose length is data-driven, so a NUL in a value ends that
  parameter and everything after it is read by the server as further parameters -- an `application_name` of
  `x\x00user\x00admin` changed the role the connection logged in as. libpq cannot reach this state because its
  parameters are NUL-terminated C strings. `Connect` now fails with nothing written to the wire, which covers
  settings that bypass connection string parsing: service files and direct assignment to `Config.RuntimeParams`,
  `Config.User`, or `Config.Database`.
* pgconn: keyword/value connection strings containing a NUL byte are rejected by `ParseConfig`, as URIs already were.

# 5.10.0 (June 3, 2026)

This release includes a significant amount of hardening against malicious or compromised PostgreSQL servers,
contributed by Sean Chittenden at CrowdStrike, Inc. This work bounds binary decoders against attacker-controlled
message sizes, caps server-supplied SCRAM iteration counts, adds `require_auth` to restrict which authentication
methods a server may use (mitigating downgrade attacks under `sslmode=prefer`), and ensures cancellation requests are
sent over TLS when the original connection used TLS.

## Features

* Add `require_auth` to restrict accepted server authentication methods (Sean Chittenden at CrowdStrike, Inc.)
* Add `ParseConfigOptions.ConnStringAllowedKeys` to restrict allowed connection string keys (Sean Chittenden at CrowdStrike, Inc.)
* Add `StructArgs` and `StrictStructArgs` for `@`-named queries (Tubelight30)
* Add `ErrConnClosed` sentinel error and unwrap it from `connLockError` (Charlie Tonneslan)
* pgxpool: check if connection is expired before acquire (arthurdotwork)

## Security Hardening

* Encrypt `CancelRequest` connection when the primary connection used TLS (Sean Chittenden at CrowdStrike, Inc.)
* Cap server-supplied SCRAM iteration count (Sean Chittenden at CrowdStrike, Inc.)
* Default Frontend max message body length to ~1 GiB (Sean Chittenden at CrowdStrike, Inc.)
* Bound hstore binary decode against malicious server input (Sean Chittenden at CrowdStrike, Inc.)
* Bound array binary decode element length against remaining message bytes (Sean Chittenden at CrowdStrike, Inc.)
* Bound array element count against remaining message bytes (Sean Chittenden at CrowdStrike, Inc.)
* Bound range, multirange, and tsvector binary decoders (Sean Chittenden at CrowdStrike, Inc.)
* Document secure connection configuration (Sean Chittenden at CrowdStrike, Inc.)
* Fix panic on malformed geometric text; return an error instead (MaIII)

## Fixes

* Fix scanning `"char"` (OID 18) into `*string` in binary format (luongs3)
* Fix handling of typed-nil `driver.Valuer` in array and composite codecs (Donncha Fahy)
* Fix `CopyData.Data` hex decoding in `UnmarshalJSON` (Charlie Tonneslan)
* Fix data race when context is cancelled during connect
* Fix `parseKeywordValueSettings` rejecting trailing whitespace (alliasgher)
* pgconn: preserve full error chain in `normalizeTimeoutError` (Charlie Tonneslan)
* pgconn: use a fresh context for the fallback connection in `connectPreferred` (Charlie Tonneslan)
* pgxpool: fix `MaxLifetimeDestroyCount` and ping order for acquire-time expiry check
* Add missing error check of `rows.Err` to load types (Jen Altavilla)

# 5.9.2 (April 18, 2026)

Fix SQL Injection via placeholder confusion with dollar quoted string literals (GHSA-j88v-2chj-qfwx)

SQL injection can occur when:

1. The non-default simple protocol is used.
2. A dollar quoted string literal is used in the SQL query.
3. That query contains text that would be would be interpreted outside as a placeholder outside of a string literal.
4. The value of that placeholder is controllable by the attacker.

e.g.

```go
attackValue := `$tag$; drop table canary; --`
_, err = tx.Exec(ctx, `select $tag$ $1 $tag$, $1`, pgx.QueryExecModeSimpleProtocol, attackValue)
```

This is unlikely to occur outside of a contrived scenario.

# 5.9.1 (March 22, 2026)

* Fix: batch result format corruption when using cached prepared statements (reported by Dirkjan Bussink)

# 5.9.0 (March 21, 2026)

This release includes a number of new features such as SCRAM-SHA-256-PLUS support, OAuth authentication support, and
PostgreSQL protocol 3.2 support.

It significantly reduces the amount of network traffic when using prepared statements (which are used automatically by
default) by avoiding unnecessary Describe Portal messages. This also reduces local memory usage.

It also includes multiple fixes for potential DoS due to panic or OOM if connected to a malicious server that sends
deliberately malformed messages.

* Require Go 1.25+
* Add SCRAM-SHA-256-PLUS support (Adam Brightwell)
* Add OAuth authentication support for PostgreSQL 18 (David Schneider)
* Add PostgreSQL protocol 3.2 support (Dirkjan Bussink)
* Add tsvector type support (Adam Brightwell)
* Skip Describe Portal for cached prepared statements reducing network round trips
* Make LoadTypes query easier to support on "postgres-like" servers (Jelte Fennema-Nio)
* Default empty user to current OS user matching libpq behavior (ShivangSrivastava)
* Optimize LRU statement cache with custom linked list and node pooling (Mathias Bogaert)
* Optimize date scanning by replacing regex with manual parsing (Mathias Bogaert)
* Optimize pgio append/set functions with direct byte shifts (Mathias Bogaert)
* Make RowsAffected faster (Abhishek Chanda)
* Fix: Pipeline.Close panic when server sends multiple FATAL errors (Varun Chawla)
* Fix: ContextWatcher goroutine leak (Hank Donnay)
* Fix: stdlib discard connections with open transactions in ResetSession (Jeremy Schneider)
* Fix: pipelineBatchResults.Exec silently swallowing lastRows error
* Fix: ColumnTypeLength using BPCharArrayOID instead of BPCharOID
* Fix: TSVector text encoding returning nil for valid empty tsvector
* Fix: wrong error messages for Int2 and Int4 underflow
* Fix: Numeric nil Int pointer dereference with Valid: true
* Fix: reversed strings.ContainsAny arguments in Numeric.ScanScientific
* Fix: message length parsing on 32-bit platforms
* Fix: FunctionCallResponse.Decode mishandling of signed result size
* Fix: returning wrong error in configTLS when DecryptPEMBlock fails (Maxim Motyshen)
* Fix: misleading ParseConfig error when default_query_exec_mode is invalid (Skarm)
* Fix: missed Unwatch in Pipeline error paths
* Clarify too many failed acquire attempts error message
* Better error wrapping with context and SQL statement (Aneesh Makala)
* Enable govet and ineffassign linters (Federico Guerinoni)
* Guard against various malformed binary messages (arrays, hstore, multirange, protocol messages)
* Fix various godoc comments (ferhat elmas)
* Fix typos in comments (Oleksandr Redko)

# 5.8.0 (December 26, 2025)

* Require Go 1.24+
* Remove golang.org/x/crypto dependency
* Add OptionShouldPing to control ResetSession ping behavior (ilyam8)
* Fix: Avoid overflow when MaxConns is set to MaxInt32
* Fix: Close batch pipeline after a query error (Anthonin Bonnefoy)
* Faster shutdown of pgxpool.Pool background goroutines (Blake Gentry)
* Add pgxpool ping timeout (Amirsalar Safaei)
* Fix: Rows.FieldDescriptions for empty query
* Scan unknown types into *any as string or []byte based on format code
* Optimize pgtype.Numeric (Philip Dubé)
* Add AfterNetConnect hook to pgconn.Config
* Fix: Handle for preparing statements that fail during the Describe phase
* Fix overflow in numeric scanning (Ilia Demianenko)
* Fix: json/jsonb sql.Scanner source type is []byte
* Migrate from math/rand to math/rand/v2 (Mathias Bogaert)
* Optimize internal iobufpool (Mathias Bogaert)
* Optimize stmtcache invalidation (Mathias Bogaert)
* Fix: missing error case in interval parsing (Maxime Soulé)
* Fix: invalidate statement/description cache in Exec (James Hartig)
* ColumnTypeLength method return the type length for varbit type (DengChan)
* Array and Composite codecs handle typed nils

# 5.7.6 (September 8, 2025)

* Use ParseConfigError in pgx.ParseConfig and pgxpool.ParseConfig (Yurasov Ilia)
* Add PrepareConn hook to pgxpool (Jonathan Hall)
* Reduce allocations in QueryContext (Dominique Lefevre)
* Add MarshalJSON and UnmarshalJSON for pgtype.Uint32 (Panos Koutsovasilis)
* Configure ping behavior on pgxpool with ShouldPing (Christian Kiely)
* zeronull int types implement Int64Valuer and Int64Scanner (Li Zeghong)
* Fix panic when receiving terminate connection message during CopyFrom (Michal Drausowski)
* Fix statement cache not being invalidated on error during batch (Muhammadali Nazarov)

# 5.7.5 (May 17, 2025)

* Support sslnegotiation connection option (divyam234)
* Update golang.org/x/crypto to v0.37.0. This placates security scanners that were unable to see that pgx did not use the behavior affected by https://pkg.go.dev/vuln/GO-2025-3487.
* TraceLog now logs Acquire and Release at the debug level (dave sinclair)
* Add support for PGTZ environment variable
* Add support for PGOPTIONS environment variable
* Unpin memory used by Rows quicker
* Remove PlanScan memoization. This resolves a rare issue where scanning could be broken for one type by first scanning another. The problem was in the memoization system and benchmarking revealed that memoization was not providing any meaningful benefit.

# 5.7.4 (March 24, 2025)

* Fix / revert change to scanning JSON `null` (Felix Röhrich)

# 5.7.3 (March 21, 2025)

* Expose EmptyAcquireWaitTime in pgxpool.Stat (vamshiaruru32)
* Improve SQL sanitizer performance (ninedraft)
* Fix Scan confusion with json(b), sql.Scanner, and automatic dereferencing (moukoublen, felix-roehrich)
* Fix Values() for xml type always returning nil instead of []byte
* Add ability to send Flush message in pipeline mode (zenkovev)
* Fix pgtype.Timestamp's JSON behavior to match PostgreSQL (pconstantinou)
* Better error messages when scanning structs (logicbomb)
* Fix handling of error on batch write (bonnefoa)
* Match libpq's connection fallback behavior more closely (felix-roehrich)
* Add MinIdleConns to pgxpool (djahandarie)

# 5.7.2 (December 21, 2024)

* Fix prepared statement already exists on batch prepare failure
* Add commit query to tx options (Lucas Hild)
* Fix pgtype.Timestamp json unmarshal (Shean de Montigny-Desautels)
* Add message body size limits in frontend and backend (zene)
* Add xid8 type
* Ensure planning encodes and scans cannot infinitely recurse
* Implement pgtype.UUID.String() (Konstantin Grachev)
* Switch from ExecParams to Exec in ValidateConnectTargetSessionAttrs functions (Alexander Rumyantsev)
* Update golang.org/x/crypto
* Fix json(b) columns prefer sql.Scanner interface like database/sql (Ludovico Russo)

# 5.7.1 (September 10, 2024)

* Fix data race in tracelog.TraceLog
* Update puddle to v2.2.2. This removes the import of nanotime via linkname.
* Update golang.org/x/crypto and golang.org/x/text

# 5.7.0 (September 7, 2024)

* Add support for sslrootcert=system (Yann Soubeyrand)
* Add LoadTypes to load multiple types in a single SQL query (Nick Farrell)
* Add XMLCodec supports encoding + scanning XML column type like json (nickcruess-soda)
* Add MultiTrace (Stepan Rabotkin)
* Add TraceLogConfig with customizable TimeKey (stringintech)
* pgx.ErrNoRows wraps sql.ErrNoRows to aid in database/sql compatibility with native pgx functions (merlin)
* Support scanning binary formatted uint32 into string / TextScanner (jennifersp)
* Fix interval encoding to allow 0s and avoid extra spaces (Carlos Pérez-Aradros Herce)
* Update pgservicefile - fixes panic when parsing invalid file
* Better error message when reading past end of batch
* Don't print url when url.Parse returns an error (Kevin Biju)
* Fix snake case name normalization collision in RowToStructByName with db tag (nolandseigler)
* Fix: Scan and encode types with underlying types of arrays

# 5.6.0 (May 25, 2024)

* Add StrictNamedArgs (Tomas Zahradnicek)
* Add support for macaddr8 type (Carlos Pérez-Aradros Herce)
* Add SeverityUnlocalized field to PgError / Notice
* Performance optimization of RowToStructByPos/Name (Zach Olstein)
* Allow customizing context canceled behavior for pgconn
* Add ScanLocation to pgtype.Timestamp[tz]Codec
* Add custom data to pgconn.PgConn
* Fix ResultReader.Read() to handle nil values
* Do not encode interval microseconds when they are 0 (Carlos Pérez-Aradros Herce)
* pgconn.SafeToRetry checks for wrapped errors (tjasko)
* Failed connection attempts include all errors
* Optimize LargeObject.Read (Mitar)
* Add tracing for connection acquire and release from pool (ngavinsir)
* Fix encode driver.Valuer not called when nil
* Add support for custom JSON marshal and unmarshal (Mitar)
* Use Go default keepalive for TCP connections (Hans-Joachim Kliemeck)

# 5.5.5 (March 9, 2024)

Use spaces instead of parentheses for SQL sanitization.

This still solves the problem of negative numbers creating a line comment, but this avoids breaking edge cases such as
`set foo to $1` where the substitution is taking place in a location where an arbitrary expression is not allowed.

# 5.5.4 (March 4, 2024)

Fix CVE-2024-27304

SQL injection can occur if an attacker can cause a single query or bind message to exceed 4 GB in size. An integer
overflow in the calculated message size can cause the one large message to be sent as multiple messages under the
attacker's control.

Thanks to Paul Gerste for reporting this issue.

* Fix behavior of CollectRows to return empty slice if Rows are empty (Felix)
* Fix simple protocol encoding of json.RawMessage
* Fix *Pipeline.getResults should close pipeline on error
* Fix panic in TryFindUnderlyingTypeScanPlan (David Kurman)
* Fix deallocation of invalidated cached statements in a transaction
* Handle invalid sslkey file
* Fix scan float4 into sql.Scanner
* Fix pgtype.Bits not making copy of data from read buffer. This would cause the data to be corrupted by future reads.

# 5.5.3 (February 3, 2024)

* Fix: prepared statement already exists
* Improve CopyFrom auto-conversion of text-ish values
* Add ltree type support (Florent Viel)
* Make some properties of Batch and QueuedQuery public (Pavlo Golub)
* Add AppendRows function (Edoardo Spadolini)
* Optimize convert UUID [16]byte to string (Kirill Malikov)
* Fix: LargeObject Read and Write of more than ~1GB at a time (Mitar)

# 5.5.2 (January 13, 2024)

* Allow NamedArgs to start with underscore
* pgproto3: Maximum message body length support (jeremy.spriet)
* Upgrade golang.org/x/crypto to v0.17.0
* Add snake_case support to RowToStructByName (Tikhon Fedulov)
* Fix: update description cache after exec prepare (James Hartig)
* Fix: pipeline checks if it is closed (James Hartig and Ryan Fowler)
* Fix: normalize timeout / context errors during TLS startup (Samuel Stauffer)
* Add OnPgError for easier centralized error handling (James Hartig)

# 5.5.1 (December 9, 2023)

* Add CopyFromFunc helper function. (robford)
* Add PgConn.Deallocate method that uses PostgreSQL protocol Close message.
* pgx uses new PgConn.Deallocate method. This allows deallocating statements to work in a failed transaction. This fixes a case where the prepared statement map could become invalid.
* Fix: Prefer driver.Valuer over json.Marshaler for json fields. (Jacopo)
* Fix: simple protocol SQL sanitizer previously panicked if an invalid $0 placeholder was used. This now returns an error instead. (maksymnevajdev)
* Add pgtype.Numeric.ScanScientific (Eshton Robateau)

# 5.5.0 (November 4, 2023)

* Add CollectExactlyOneRow. (Julien GOTTELAND)
* Add OpenDBFromPool to create *database/sql.DB from *pgxpool.Pool. (Lev Zakharov)
* Prepare can automatically choose statement name based on sql. This makes it easier to explicitly manage prepared statements.
* Statement cache now uses deterministic, stable statement names.
* database/sql prepared statement names are deterministically generated.
* Fix: SendBatch wasn't respecting context cancellation.
* Fix: Timeout error from pipeline is now normalized.
* Fix: database/sql encoding json.RawMessage to []byte.
* CancelRequest: Wait for the cancel request to be acknowledged by the server. This should improve PgBouncer compatibility. (Anton Levakin)
* stdlib: Use Ping instead of CheckConn in ResetSession
* Add json.Marshaler and json.Unmarshaler for Float4, Float8 (Kirill Mironov)

# 5.4.3 (August 5, 2023)

* Fix: QCharArrayOID was defined with the wrong OID (Christoph Engelbert)
* Fix: connect_timeout for sslmode=allow|prefer (smaher-edb)
* Fix: pgxpool: background health check cannot overflow pool
* Fix: Check for nil in defer when sending batch (recover properly from panic)
* Fix: json scan of non-string pointer to pointer
* Fix: zeronull.Timestamptz should use pgtype.Timestamptz
* Fix: NewConnsCount was not correctly counting connections created by Acquire directly. (James Hartig)
* RowTo(AddrOf)StructByPos ignores fields with "-" db tag
* Optimization: improve text format numeric parsing (horpto)

# 5.4.2 (July 11, 2023)

* Fix: RowScanner errors are fatal to Rows
* Fix: Enable failover efforts when pg_hba.conf disallows non-ssl connections (Brandon Kauffman)
* Hstore text codec internal improvements (Evan Jones)
* Fix: Stop timers for background reader when not in use. Fixes memory leak when closing connections (Adrian-Stefan Mares)
* Fix: Stop background reader as soon as possible.
* Add PgConn.SyncConn(). This combined with the above fix makes it safe to directly use the underlying net.Conn.

# 5.4.1 (June 18, 2023)

* Fix: concurrency bug with pgtypeDefaultMap and simple protocol (Lev Zakharov)
* Add TxOptions.BeginQuery to allow overriding the default BEGIN query

# 5.4.0 (June 14, 2023)

* Replace platform specific syscalls for non-blocking IO with more traditional goroutines and deadlines. This returns to the v4 approach with some additional improvements and fixes. This restores the ability to use a pgx.Conn over an ssh.Conn as well as other non-TCP or Unix socket connections. In addition, it is a significantly simpler implementation that is less likely to have cross platform issues.
* Optimization: The default type registrations are now shared among all connections. This saves about 100KB of memory per connection. `pgtype.Type` and `pgtype.Codec` values are now required to be immutable after registration. This was already necessary in most cases but wasn't documented until now. (Lev Zakharov)
* Fix: Ensure pgxpool.Pool.QueryRow.Scan releases connection on panic
* CancelRequest: don't try to read the reply (Nicola Murino)
* Fix: correctly handle bool type aliases (Wichert Akkerman)
* Fix: pgconn.CancelRequest: Fix unix sockets: don't use RemoteAddr()
* Fix: pgx.Conn memory leak with prepared statement caching (Evan Jones)
* Add BeforeClose to pgxpool.Pool (Evan Cordell)
* Fix: various hstore fixes and optimizations (Evan Jones)
* Fix: RowToStructByPos with embedded unexported struct
* Support different bool string representations (Lev Zakharov)
* Fix: error when using BatchResults.Exec on a select that returns an error after some rows.
* Fix: pipelineBatchResults.Exec() not returning error from ResultReader
* Fix: pipeline batch results not closing pipeline when error occurs while reading directly from results instead of using
    a callback.
* Fix: scanning a table type into a struct
* Fix: scan array of record to pointer to slice of struct
* Fix: handle null for json (Cemre Mengu)
* Batch Query callback is called even when there is an error
* Add RowTo(AddrOf)StructByNameLax (Audi P. Risa P)

# 5.3.1 (February 27, 2023)

* Fix: Support v4 and v5 stdlib in same program (Tomáš Procházka)
* Fix: sql.Scanner not being used in certain cases
* Add text format jsonpath support
* Fix: fake non-blocking read adaptive wait time

# 5.3.0 (February 11, 2023)

* Fix: json values work with sql.Scanner
* Fixed / improved error messages (Mark Chambers and Yevgeny Pats)
* Fix: support scan into single dimensional arrays
* Fix: MaxConnLifetimeJitter setting actually jitter (Ben Weintraub)
* Fix: driver.Value representation of bytea should be []byte not string
* Fix: better handling of unregistered OIDs
* CopyFrom can use query cache to avoid extra round trip to get OIDs (Alejandro Do Nascimento Mora)
* Fix: encode to json ignoring driver.Valuer
* Support sql.Scanner on renamed base type
* Fix: pgtype.Numeric text encoding of negative numbers (Mark Chambers)
* Fix: connect with multiple hostnames when one can't be resolved
* Upgrade puddle to remove dependency on uber/atomic and fix alignment issue on 32-bit platform
* Fix: scanning json column into **string
* Multiple reductions in memory allocations
* Fake non-blocking read adapts its max wait time
* Improve CopyFrom performance and reduce memory usage
* Fix: encode []any to array
* Fix: LoadType for composite with dropped attributes (Felix Röhrich)
* Support v4 and v5 stdlib in same program
* Fix: text format array decoding with string of "NULL"
* Prefer binary format for arrays

# 5.2.0 (December 5, 2022)

* `tracelog.TraceLog` implements the pgx.PrepareTracer interface. (Vitalii Solodilov)
* Optimize creating begin transaction SQL string (Petr Evdokimov and ksco)
* `Conn.LoadType` supports range and multirange types (Vitalii Solodilov)
* Fix scan `uint` and `uint64` `ScanNumeric`. This resolves a PostgreSQL `numeric` being incorrectly scanned into `uint` and `uint64`.

# 5.1.1 (November 17, 2022)

* Fix simple query sanitizer where query text contains a Unicode replacement character.
* Remove erroneous `name` argument from `DeallocateAll()`. Technically, this is a breaking change, but given that method was only added 5 days ago this change was accepted. (Bodo Kaiser)

# 5.1.0 (November 12, 2022)

* Update puddle to v2.1.2. This resolves a race condition and a deadlock in pgxpool.
* `QueryRewriter.RewriteQuery` now returns an error. Technically, this is a breaking change for any external implementers, but given the minimal likelihood that there are actually any external implementers this change was accepted.
* Expose `GetSSLPassword` support to pgx.
* Fix encode `ErrorResponse` unknown field handling. This would only affect pgproto3 being used directly as a proxy with a non-PostgreSQL server that included additional error fields.
* Fix date text format encoding with 5 digit years.
* Fix date values passed to a `sql.Scanner` as `string` instead of `time.Time`.
* DateCodec.DecodeValue can return `pgtype.InfinityModifier` instead of `string` for infinite values. This now matches the behavior of the timestamp types.
* Add domain type support to `Conn.LoadType()`.
* Add `RowToStructByName` and `RowToAddrOfStructByName`. (Pavlo Golub)
* Add `Conn.DeallocateAll()` to clear all prepared statements including the statement cache. (Bodo Kaiser)

# 5.0.4 (October 24, 2022)

* Fix: CollectOneRow prefers PostgreSQL error over pgx.ErrorNoRows
* Fix: some reflect Kind checks to first check for nil
* Bump golang.org/x/text dependency to placate snyk
* Fix: RowToStructByPos on structs with multiple anonymous sub-structs (Baptiste Fontaine)
* Fix: Exec checks if tx is closed

# 5.0.3 (October 14, 2022)

* Fix `driver.Valuer` handling edge cases that could cause infinite loop or crash

# v5.0.2 (October 8, 2022)

* Fix date encoding in text format to always use 2 digits for month and day
* Prefer driver.Valuer over wrap plans when encoding
* Fix scan to pointer to pointer to renamed type
* Allow scanning NULL even if PG and Go types are incompatible

# v5.0.1 (September 24, 2022)

* Fix 32-bit atomic usage
* Add MarshalJSON for Float8 (yogipristiawan)
* Add `[` and `]` to text encoding of `Lseg`
* Fix sqlScannerWrapper NULL handling

# v5.0.0 (September 17, 2022)

## Merged Packages

`github.com/jackc/pgtype`, `github.com/jackc/pgconn`, and `github.com/jackc/pgproto3` are now included in the main
`github.com/jackc/pgx` repository. Previously there was confusion as to where issues should be reported, additional
release work due to releasing multiple packages, and less clear changelogs.

## pgconn

`CommandTag` is now an opaque type instead of directly exposing an underlying `[]byte`.

The return value `ResultReader.Values()` is no longer safe to retain a reference to after a subsequent call to `NextRow()` or `Close()`.

`Trace()` method adds low level message tracing similar to the `PQtrace` function in `libpq`.

pgconn now uses non-blocking IO. This is a significant internal restructuring, but it should not cause any visible changes on its own. However, it is important in implementing other new features.

`CheckConn()` checks a connection's liveness by doing a non-blocking read. This can be used to detect database restarts or network interruptions without executing a query or a ping.

pgconn now supports pipeline mode.

`*PgConn.ReceiveResults` removed. Use pipeline mode instead.

`Timeout()` no longer considers `context.Canceled` as a timeout error. `context.DeadlineExceeded` still is considered a timeout error.

## pgxpool

`Connect` and `ConnectConfig` have been renamed to `New` and `NewWithConfig` respectively. The `LazyConnect` option has been removed. Pools always lazily connect.

## pgtype

The `pgtype` package has been significantly changed.

### NULL Representation

Previously, types had a `Status` field that could be `Undefined`, `Null`, or `Present`. This has been changed to a
`Valid` `bool` field to harmonize with how `database/sql` represents `NULL` and to make the zero value useable.

Previously, a type that implemented `driver.Valuer` would have the `Value` method called even on a nil pointer. All nils
whether typed or untyped now represent `NULL`.

### Codec and Value Split

Previously, the type system combined decoding and encoding values with the value types. e.g. Type `Int8` both handled
encoding and decoding the PostgreSQL representation and acted as a value object. This caused some difficulties when
there was not an exact 1 to 1 relationship between the Go types and the PostgreSQL types For example, scanning a
PostgreSQL binary `numeric` into a Go `float64` was awkward (see https://github.com/jackc/pgtype/issues/147). This
concepts have been separated. A `Codec` only has responsibility for encoding and decoding values. Value types are
generally defined by implementing an interface that a particular `Codec` understands (e.g. `PointScanner` and
`PointValuer` for the PostgreSQL `point` type).

### Array Types

All array types are now handled by `ArrayCodec` instead of using code generation for each new array type. This also
means that less common array types such as `point[]` are now supported. `Array[T]` supports PostgreSQL multi-dimensional
arrays.

### Composite Types

Composite types must be registered before use. `CompositeFields` may still be used to construct and destruct composite
values, but any type may now implement `CompositeIndexGetter` and `CompositeIndexScanner` to be used as a composite.

### Range Types

Range types are now handled with types `RangeCodec` and `Range[T]`. This allows additional user defined range types to
easily be handled. Multirange types are handled similarly with `MultirangeCodec` and `Multirange[T]`.

### pgxtype

`LoadDataType` moved to `*Conn` as `LoadType`.

### Bytea

The `Bytea` and `GenericBinary` types have been replaced. Use the following instead:

* `[]byte` - For normal usage directly use `[]byte`.
* `DriverBytes` - Uses driver memory only available until next database method call. Avoids a copy and an allocation.
* `PreallocBytes` - Uses preallocated byte slice to avoid an allocation.
* `UndecodedBytes` - Avoids any decoding. Allows working with raw bytes.

### Dropped lib/pq Support

`pgtype` previously supported and was tested against [lib/pq](https://github.com/lib/pq). While it will continue to work
in most cases this is no longer supported.

### database/sql Scan

Previously, most `Scan` implementations would convert `[]byte` to `string` automatically to decode a text value. Now
only `string` is handled. This is to allow the possibility of future binary support in `database/sql` mode by
considering `[]byte` to be binary format and `string` text format. This change should have no effect for any use with
`pgx`. The previous behavior was only necessary for `lib/pq` compatibility.

Added `*Map.SQLScanner` to create a `sql.Scanner` for types such as `[]int32` and `Range[T]` that do not implement
`sql.Scanner` directly.

### Number Type Fields Include Bit size

`Int2`, `Int4`, `Int8`, `Float4`, `Float8`, and `Uint32` fields now include bit size. e.g. `Int` is renamed to `Int64`.
This matches the convention set by `database/sql`. In addition, for comparable types like `pgtype.Int8` and
`sql.NullInt64` the structures are identical. This means they can be directly converted one to another.

### 3rd Party Type Integrations

* Extracted integrations with https://github.com/shopspring/decimal and https://github.com/gofrs/uuid to
  https://github.com/jackc/pgx-shopspring-decimal and https://github.com/jackc/pgx-gofrs-uuid respectively. This trims
  the pgx dependency tree.

### Other Changes

* `Bit` and `Varbit` are both replaced by the `Bits` type.
* `CID`, `OID`, `OIDValue`, and `XID` are replaced by the `Uint32` type.
* `Hstore` is now defined as `map[string]*string`.
* `JSON` and `JSONB` types removed. Use `[]byte` or `string` directly.
* `QChar` type removed. Use `rune` or `byte` directly.
* `Inet` and `Cidr` types removed. Use `netip.Addr` and `netip.Prefix` directly. These types are more memory efficient than the previous `net.IPNet`.
* `Macaddr` type removed. Use `net.HardwareAddr` directly.
* Renamed `pgtype.ConnInfo` to `pgtype.Map`.
* Renamed `pgtype.DataType` to `pgtype.Type`.
* Renamed `pgtype.None` to `pgtype.Finite`.
* `RegisterType` now accepts a `*Type` instead of `Type`.
* Assorted array helper methods and types made private.

## stdlib

* Removed `AcquireConn` and `ReleaseConn` as that functionality has been built in since Go 1.13.

## Reduced Memory Usage by Reusing Read Buffers

Previously, the connection read buffer would allocate large chunks of memory and never reuse them. This allowed
transferring ownership to anything such as scanned values without incurring an additional allocation and memory copy.
However, this came at the cost of overall increased memory allocation size. But worse it was also possible to pin large
chunks of memory by retaining a reference to a small value that originally came directly from the read buffer. Now
ownership remains with the read buffer and anything needing to retain a value must make a copy.

## Query Execution Modes

Control over automatic prepared statement caching and simple protocol use are now combined into query execution mode.
See documentation for `QueryExecMode`.

## QueryRewriter Interface and NamedArgs

pgx now supports named arguments with the `NamedArgs` type. This is implemented via the new `QueryRewriter` interface which
allows arbitrary rewriting of query SQL and arguments.

## RowScanner Interface

The `RowScanner` interface allows a single argument to Rows.Scan to scan the entire row.

## Rows Result Helpers

* `CollectRows` and `RowTo*` functions simplify collecting results into a slice.
* `CollectOneRow` collects one row using `RowTo*` functions.
* `ForEachRow` simplifies scanning each row and executing code using the scanned values. `ForEachRow` replaces `QueryFunc`.

## Tx Helpers

Rather than every type that implemented `Begin` or `BeginTx` methods also needing to implement `BeginFunc` and
`BeginTxFunc` these methods have been converted to functions that take a db that implements `Begin` or `BeginTx`.

## Improved Batch Query Ergonomics

Previously, the code for building a batch went in one place before the call to `SendBatch`, and the code for reading the
results went in one place after the call to `SendBatch`. This could make it difficult to match up the query and the code
to handle the results. Now `Queue` returns a `QueuedQuery` which has methods `Query`, `QueryRow`, and `Exec` which can
be used to register a callback function that will handle the result. Callback functions are called automatically when
`BatchResults.Close` is called.

## SendBatch Uses Pipeline Mode When Appropriate

Previously, a batch with 10 unique parameterized statements executed 100 times would entail 11 network round trips. 1
for each prepare / describe and 1 for executing them all. Now pipeline mode is used to prepare / describe all statements
in a single network round trip. So it would only take 2 round trips.

## Tracing and Logging

Internal logging support has been replaced with tracing hooks. This allows custom tracing integration with tools like OpenTelemetry. Package tracelog provides an adapter for pgx v4 loggers to act as a tracer.

All integrations with 3rd party loggers have been extracted to separate repositories. This trims the pgx dependency
tree.
